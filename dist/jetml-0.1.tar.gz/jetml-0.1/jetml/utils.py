import jetmath as jm

def array_to_vector(x):
    return jm.matrix.matrix.transpose(jm.matrix.matrix([x]))

